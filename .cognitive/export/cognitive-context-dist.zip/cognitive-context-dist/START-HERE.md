# 🚀 Quick Start

## Copy this prompt to your AI agent:

```
I want to set up Cognitive Context for this project.

Read the file ONBOARDING-AGENT.md and execute the complete onboarding protocol.

Requirements:
- Do NOT skip any phase
- Create exhaustive inventory (list EVERY component, not examples)
- Use real code from THIS project, not generic templates
- Ask me questions when you need clarification

Start now.
```

That's it. Your AI will handle everything else.

---

**What happens next:**
1. AI creates a git checkpoint (safety first)
2. AI scans your entire codebase
3. AI asks you specific questions about your conventions
4. AI generates `.cognitive/` with real data from your project
5. AI installs integrations for your tools (Cursor, Claude, etc.)

**Time:** ~10-15 minutes of conversation

**Result:** Every future AI session starts with full project knowledge

---

See `README.md` for details on what Cognitive Context does and why.
