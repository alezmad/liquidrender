# Troubleshooting

Common issues and solutions.

---

## Installation Issues

### "command not found: cognitive"

**Cause:** CLI not in PATH after install.

**Fix:**
```bash
# Use npx instead
npx cognitive init

# Or check global install
npm list -g cognitive-context
```

### "Cannot find module" errors

**Cause:** Dependencies not installed.

**Fix:**
```bash
cd cognitive-context
npm install
```

### Permission denied on install.sh

**Fix:**
```bash
chmod +x install.sh
./install.sh
```

---

## Runtime Issues

### "No .cognitive/ folder found"

**Cause:** Not initialized yet.

**Fix:**
```bash
npx cognitive init
```

Or use AI installation (recommended):
```
Read ONBOARDING-AGENT.md and execute the onboarding protocol.
```

### AI keeps rebuilding existing components

**Cause:** `capabilities.yaml` is incomplete.

**Fix:**
```
Run /context-maintain and let it scan for missing components.
```

### AI ignores my conventions

**Cause:** `rules.yaml` missing or incomplete.

**Fix:** Edit `.cognitive/rules.yaml` with your conventions, or prompt AI:
```
Review my codebase patterns and update .cognitive/rules.yaml with conventions you observe.
```

---

## Drift & Sync Issues

### "cognitive drift" shows many missing files

**Cause:** `knowledge.json` is stale.

**Fix:**
```bash
npx cognitive sync
```

### Changes not reflected in Cursor/Claude

**Cause:** Adapters not synced.

**Fix:**
```bash
bash .cognitive/adapters/sync-all.sh
```

---

## Command Issues

### /context-check shows wrong counts

**Cause:** Find command syntax differs between macOS and Linux.

**Fix:** The commands use macOS syntax. On Linux, modify the stat command:
```bash
# macOS
stat -f %m file

# Linux
stat -c %Y file
```

### /resume-report errors

**Cause:** Usually git or find command differences.

**Fix:** Ensure you're in the project root with a git repo:
```bash
git status  # Should work
```

---

## AI-Specific Issues

### AI doesn't read .cognitive/ files

**Cause:** Not referenced in CLAUDE.md or Cursor rules.

**Fix:** Add to your CLAUDE.md:
```markdown
> **After reading this file:** Read `.cognitive/SUMMARY.md` then `.cognitive/capabilities.yaml`.
```

### AI reads wrong context files

**Cause:** Multiple context systems conflicting.

**Fix:** Establish hierarchy in CLAUDE.md:
```markdown
## Conflict Resolution
1. User's explicit instruction (highest)
2. .cognitive/SUMMARY.md
3. .cognitive/capabilities.yaml
4. Other docs (lowest)
```

---

## Getting Help

1. Run `/context-maintain` for diagnostic report
2. Check file permissions: `ls -la .cognitive/`
3. Verify git status: `git status`
4. Check package.json for conflicting deps

---

## Rollback

If something breaks after setup:

```bash
# If you created a checkpoint during onboarding
git checkout cognitive-pre-setup-*

# Or restore from backup
git stash
git checkout HEAD -- .cognitive/
```
