#!/bin/sh
# Install cognitive-context in a project
set -e
echo "Installing cognitive-context..."

# Detect package manager
if command -v pnpm >/dev/null 2>&1; then
  pnpm add ./cognitive-context
elif command -v npm >/dev/null 2>&1; then
  npm install ./cognitive-context
elif command -v yarn >/dev/null 2>&1; then
  yarn add ./cognitive-context
else
  echo "Error: No package manager found (pnpm, npm, or yarn)"
  exit 1
fi

echo ""
echo "✓ Installed. Next steps:"
echo "  1. Run: npx cognitive init"
echo "  2. Or use AI installation (see README.md)"
