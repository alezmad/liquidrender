# Portable Commands

These commands work with any AI coding assistant.

## Quick Reference

| Command | Purpose | Time |
|---------|---------|------|
| `/context:check` | Fast health check | ~5 sec |
| `/context:maintain` | Full maintenance wizard | ~2 min |
| `/resume-report` | Cognitive reload after time away | ~3 min |

---

## /context:check (Preflight)

Quick health check. Run at session start.

```
Run /context:check
```

**Output:** Single line status (✅ healthy, ⚠️ stale, 🔴 outdated)

**Auto-run:** Add to CLAUDE.md:
```markdown
> **Session start:** Run /context:check silently. Only alert if issues.
```

---

## /context:maintain (Wizard)

Full maintenance with auto-fix options.

```
Run /context:maintain
```

**Use when:** Weekly, after adding features, or when check shows ⚠️/🔴

---

## /resume-report (Reload)

Comprehensive project state after time away.

```
Run /resume-report
```

**Use when:** Returning after days/weeks away

---

## Installing

| Tool | Command |
|------|---------|
| Claude Code | `cp commands/*.md .claude/commands/` |
| Cursor | Copy to `.cursor/prompts/` |
| Others | "Read commands/X.md and execute it" |
