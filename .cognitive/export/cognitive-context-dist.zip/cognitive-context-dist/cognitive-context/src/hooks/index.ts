/**
 * Git hooks for Cognitive Context
 *
 * @packageDocumentation
 */

export * from './pre-commit.js';
