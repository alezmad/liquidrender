# Cognitive Context

**Persistent memory for AI coding assistants.**

Stop repeating yourself. Stop watching AI rebuild components you already have. Stop correcting the same mistakes every session.

---

## 30-Second Start

**Copy this to your AI agent (Cursor, Claude, Copilot, etc.):**

```
I want to set up Cognitive Context for this project.

Read the file ONBOARDING-AGENT.md and execute the complete onboarding protocol.

Requirements:
- Do NOT skip any phase
- Create exhaustive inventory (list EVERY component, not examples)  
- Use real code from THIS project, not generic templates
- Ask me questions when you need clarification

Start now.
```

Your AI handles everything. You just answer questions about your preferences.

---

## Why AI-Driven Installation?

The value of Cognitive Context comes from **exhaustive inventory**. Your AI needs to know about *all 47 components*, not just 3 examples.

| Manual Setup | AI-Driven Setup |
|--------------|-----------------|
| You list components by hand | AI scans every file automatically |
| You forget half of them | AI finds everything |
| Generic templates | Real code from YOUR project |
| 2 hours of work | 15 min conversation |

**The AI that will use the context is the best one to create it.**

---

## The Problem This Solves

Every new AI session:

| Pain Point | What Happens |
|------------|--------------|
| 🔄 Re-discovery | "Let me explore your codebase..." (wastes tokens) |
| 🔁 Duplication | Creates `Button.tsx` when you already have one |
| 😤 Wrong patterns | Uses CSS when you use Tailwind |
| 🤦 Wrong stack | Suggests Prisma when you use Drizzle |

**Root cause:** AI has no memory between sessions.

**Solution:** `.cognitive/` gives AI instant project knowledge.

---

## What Gets Created

```
.cognitive/
├── SUMMARY.md           ← "Here's who we are" (always loaded)
├── capabilities.yaml    ← "Here's what exists" (don't rebuild)
├── rules.yaml           ← "Here's how we work" (conventions)
├── knowledge.json       ← "Here's everything" (entity map)
└── cache/answers/       ← "Here's how to..." (patterns)
```

Your AI loads `SUMMARY.md` (300 tokens) at session start → instant context.

---

## Before & After

| Before | After |
|--------|-------|
| 5 min context gathering | 2 seconds |
| "What components do you have?" | Already knows all 47 |
| Creates duplicate code | Uses existing components |
| Ignores conventions | Follows your patterns |
| Different behavior per tool | Same knowledge everywhere |

---

## Keeping It Fresh

Cognitive Context needs occasional updates as your codebase evolves.

| Frequency | Action | How |
|-----------|--------|-----|
| Weekly | Check for drift | `npx cognitive drift` |
| After adding features | Update inventory | Prompt AI to scan for new components |
| Monthly | Full refresh | Prompt AI to review all `.cognitive/` files |

**Quick maintenance prompt:**
```
Check if .cognitive/ is up to date. 
Scan for new components not in capabilities.yaml.
Update what's needed.
```

See **MAINTENANCE.md** for complete guide.

---

## Works With

- ✅ Cursor
- ✅ Claude Code  
- ✅ GitHub Copilot
- ✅ Continue.dev
- ✅ Aider
- ✅ Windsurf
- ✅ Any AI that can read files

---

## Complements (Not Replaces)

| Your Tool | + Cognitive Context |
|-----------|---------------------|
| **BMAD** | AI remembers project decisions |
| **Cursor Rules** | Rules + persistent memory |
| **CLAUDE.md** | Instructions + living inventory |

---

## Manual Fallback

If you prefer CLI (less thorough):

```bash
# macOS/Linux
./install.sh && npx cognitive init

# Windows
.\install.ps1; npx cognitive init
```

Then manually populate `.cognitive/` files.

---

## Files in This Package

| File | Purpose |
|------|---------|
| `START-HERE.md` | Quickest path: one prompt to copy |
| `README.md` | This file |
| `ONBOARDING-AGENT.md` | Full protocol for AI to execute |
| `MAINTENANCE.md` | How to keep context up to date |
| `cognitive-context/` | npm package with CLI |
| `install.sh` / `install.ps1` | Manual install scripts |

---

## Requirements

- Node.js 18+
- An AI coding assistant

## License

MIT

---

## Included Commands

### /resume-report

After time away, run:
```
Read commands/resume-report.md and execute it.
```

Generates a full "cognitive reload" with:
- What you were working on (narrative)
- Top 20 modified files (with AI analysis)
- Uncommitted work (risk assessment)
- Recommended next actions

See `commands/` folder for portable prompts.
