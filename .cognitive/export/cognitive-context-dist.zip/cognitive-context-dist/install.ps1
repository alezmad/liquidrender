# Install cognitive-context in a project (Windows PowerShell)
$ErrorActionPreference = "Stop"

Write-Host "Installing cognitive-context..."

if (Get-Command pnpm -ErrorAction SilentlyContinue) {
    pnpm add ./cognitive-context
} elseif (Get-Command npm -ErrorAction SilentlyContinue) {
    npm install ./cognitive-context
} elseif (Get-Command yarn -ErrorAction SilentlyContinue) {
    yarn add ./cognitive-context
} else {
    Write-Error "No package manager found (pnpm, npm, or yarn)"
    exit 1
}

Write-Host ""
Write-Host "✓ Installed. Next steps:" -ForegroundColor Green
Write-Host "  1. Run: npx cognitive init"
Write-Host "  2. Or use AI installation (see README.md)"
