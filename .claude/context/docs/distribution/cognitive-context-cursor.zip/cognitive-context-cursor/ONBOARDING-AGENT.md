# Cognitive Context Framework - Agentic Onboarding

> **For AI Agent**: Follow this protocol to set up the Cognitive Context Framework for this project.

---

## Your Mission

You are helping a developer set up the Cognitive Context Framework - a system that gives AI coding assistants persistent memory and structured understanding of their codebase.

**Your goal**: Through conversation and code analysis, create a tailored cognitive architecture that makes future AI sessions dramatically more effective.

---

## Phase 1: Safety First

Before making any changes:

1. **Check git status**
   ```bash
   git status
   ```

2. **If uncommitted changes exist**, ask user:
   > "I found uncommitted changes. Should I commit them first with message 'pre-cognitive-context-setup', or would you prefer to handle that?"

3. **Create checkpoint**
   ```bash
   git tag cognitive-pre-setup-$(date +%Y%m%d-%H%M%S)
   ```
   Tell user: "Created rollback checkpoint. If anything goes wrong: `git checkout <tag-name>`"

4. **Backup existing files** if they exist:
   - `.cursor/rules/` → `.cursor-backup-<timestamp>/`
   - `.cursorrules` → `.cursorrules.backup`

---

## Phase 2: Deep Discovery

Analyze the codebase thoroughly. Read files, don't just pattern match.

### 2.1 Project Identity

Read these files (if they exist):
- `package.json`, `Cargo.toml`, `pyproject.toml`, `go.mod`
- `README.md`
- `CLAUDE.md`, `AGENTS.md`, `.cursorrules`

Extract and synthesize:
- Project name and purpose
- What problem does it solve?
- Who is it for?

### 2.2 Architecture Analysis

Explore the codebase structure:
```bash
find . -type d -maxdepth 3 | grep -v node_modules | grep -v .git
```

Read key files to understand:
- **Entry points**: Where does execution start?
- **Core abstractions**: What are the main concepts/entities?
- **Data flow**: How does data move through the system?
- **Boundaries**: What are the module/package boundaries?

### 2.3 Technology Stack

Don't just check if React exists - understand HOW it's used:
- Which React patterns? (hooks, server components, etc.)
- State management approach?
- Styling solution?
- API layer design?

### 2.4 Existing Patterns

Read 3-5 representative files of each type:
- Components (if frontend)
- API handlers/endpoints
- Data models/schemas
- Utilities/helpers

Identify:
- Naming conventions
- File organization patterns
- Error handling approaches
- Testing patterns

### 2.5 Existing AI Context

Read any existing AI instructions:
- `.cursorrules` - What rules exist?
- `.cursor/rules/*.mdc` - What patterns are documented?
- `CLAUDE.md` - What instructions for Claude?
- `AGENTS.md` - Multi-agent instructions?

---

## Phase 3: Conversational Interview

Based on your analysis, have a conversation with the user. Don't ask generic questions - ask SPECIFIC questions based on what you found.

### Good questions (specific, based on analysis):

> "I see you have a `src/components/` with 47 components and a separate `src/ui/` with primitives. Is `ui/` your design system base that `components/` builds on?"

> "Your Prisma schema has User, Organization, and Membership models. Is this a multi-tenant SaaS? Should I document the tenancy patterns?"

> "I found three different API patterns: tRPC in `/api/trpc`, REST in `/api/v1`, and webhooks in `/api/webhooks`. Should I create wisdom files for each, or is there a preferred pattern for new endpoints?"

### Bad questions (generic, could ask without reading code):

> "What's your project about?"
> "What technology stack do you use?"
> "What are your coding conventions?"

### Key things to understand through conversation:

1. **Constraints**: What should NEVER happen?
   - "I notice you're not using Redux anywhere. Is that a deliberate choice I should enforce?"

2. **Preferences**: What approaches are preferred?
   - "You have both REST and tRPC. For new features, which should I default to?"

3. **Context**: What's not in the code?
   - "Is there a design system or Figma file I should know about?"
   - "Are there external services or APIs the code integrates with?"

4. **Pain points**: What causes friction?
   - "What mistakes do you find yourself correcting in AI suggestions?"

---

## Phase 4: Generate Cognitive Architecture

Based on your analysis and conversation, create the following:

### 4.1 Directory Structure

```bash
mkdir -p .cognitive/{wisdom,indices,schemas,scripts,templates}
mkdir -p .cursor/rules
```

### 4.2 ORIENTATION.md

Create `.cognitive/ORIENTATION.md` - the always-loaded context.

**Requirements:**
- Under 300 tokens (~400 words)
- Specific to THIS project (not generic)
- Include actual constraints discovered
- Reference actual file paths

**Template structure:**
```markdown
# {ProjectName} - Cognitive Orientation

## Identity
{One paragraph: what this is, who it's for, what problem it solves}

## Mental Model
{How to think about this codebase - be specific}

## Structure
{ASCII tree of KEY directories only - not everything}

## Hard Constraints
1. {Actual constraint from conversation}
2. {Actual constraint from code analysis}
3. {Actual constraint}

## Quick Pointers
| Task | First Read |
|------|------------|
| {Common task} | {Actual file path or @wisdom-file} |
```

### 4.3 Wisdom Files

Create `.cognitive/wisdom/` files for patterns you discovered.

**Only create wisdom for things that are:**
- Non-obvious from reading code
- Frequently needed
- Easy to get wrong

**Example wisdom files to consider:**
- `how-to-create-components.md` - If there's a specific pattern
- `api-patterns.md` - If there are multiple approaches
- `data-access.md` - If Prisma/DB patterns are specific
- `testing-patterns.md` - If testing approach is non-standard
- `architecture-decisions.md` - If there are ADRs or documented decisions

**Wisdom file structure:**
```markdown
---
description: {Max 100 chars - AI uses this to decide relevance}
confidence: {0-100}
verified_at: {today's date}
---

# {Title}

## TL;DR
{One paragraph summary}

## Pattern
{Code example from actual codebase}

## Key Points
1. {Specific to this codebase}
2. {Not generic advice}

## Anti-Patterns
- {What NOT to do here}
```

### 4.4 Entity Index

If the project has clear entities (components, models, endpoints), create `.cognitive/indices/entities.json`:

```json
{
  "meta": {
    "generated_at": "{ISO timestamp}",
    "from_commit": "{git short hash}",
    "total_entities": {count}
  },
  "entities": {
    "tier1": {
      "{EntityName}": {
        "file": "{path}",
        "type": "{component|model|endpoint|hook|utility}",
        "description": "{what it does}"
      }
    }
  }
}
```

### 4.5 Cursor Rules

Sync to `.cursor/rules/`:

**orientation.mdc**:
```markdown
---
description: Cognitive orientation - project identity and constraints
alwaysApply: true
---

{Content from ORIENTATION.md}
```

**wisdom-{name}.mdc** for each wisdom file:
```markdown
---
description: {From wisdom frontmatter}
---

{Content from wisdom file}
```

### 4.6 Sync Script

Create `sync-cursor.sh` for future syncs.

### 4.7 Git Hook (optional)

If user wants auto-sync, add post-commit hook.

---

## Phase 5: Validate and Explain

After generating everything:

1. **Show what was created**:
   ```
   Created:
   ├── .cognitive/
   │   ├── ORIENTATION.md (X tokens)
   │   ├── wisdom/
   │   │   ├── {file1}.md
   │   │   └── {file2}.md
   │   └── indices/entities.json (X entities)
   └── .cursor/rules/
       ├── orientation.mdc (always loaded)
       └── wisdom-*.mdc (X files)
   ```

2. **Explain key decisions**:
   > "I created a wisdom file for component patterns because you have a specific structure with the design tokens in utils.ts..."

3. **Invite refinement**:
   > "Take a look at the orientation - does it capture how you think about this codebase? Anything to add or change?"

4. **Confirm ready**:
   > "Your Cognitive Context is set up. The orientation will load automatically in every Cursor chat. Wisdom files load when relevant. You're ready to go!"

---

## Quality Checklist

Before finishing, verify:

- [ ] ORIENTATION.md is under 300 tokens
- [ ] All file paths in documentation actually exist
- [ ] Constraints are specific, not generic
- [ ] Wisdom files have real code examples from this project
- [ ] .cursor/rules/orientation.mdc has `alwaysApply: true`
- [ ] Sync script is executable

---

## Rollback Instructions

If something went wrong:

```bash
# Restore from checkpoint
git checkout cognitive-pre-setup-{timestamp}

# Or restore backups
cp -r .cursor-backup-{timestamp}/* .cursor/rules/
```

---

*Cognitive Context Framework - Agentic Onboarding Protocol v1.0*
